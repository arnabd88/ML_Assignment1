#!/bin/bash
clear
chmod u+x runme.sh
pip install -r ./requirements.txt
