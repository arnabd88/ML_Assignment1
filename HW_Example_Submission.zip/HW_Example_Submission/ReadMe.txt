Read Me


Here is the readme file where you explain how to run your code and 
replicate the results that you report in your paper i.e. any tables, values, etc.

# Environment 
 os name , cade machine name .

To run my code and replicate experiments in the write up:
1) Navigate to the folder titled HW_Example_Submission
2) Setup the environment

./setup.sh
3) Run the script by entering the command:

./runme.sh

4)Done
