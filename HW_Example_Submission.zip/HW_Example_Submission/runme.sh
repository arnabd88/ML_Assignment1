#!/bin/bash
clear
chmod u+x runme.sh
python Example_Submission_Code.py